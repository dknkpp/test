﻿TanuEsa3
https://vivibit.net/tanuesa3/

Discord server for supporting (mainly Japanese user, because the developer is Japanese.)
https://discord.gg/DfpHDk6X4q


This software is WITHOUT any warranty.
No one will take any responsibility if it does not work properly or malfunctions your PC.

It may not work properly depending on your anti-virus software.
(At the time of development, I have already confirmed that Norton interferes with it.)
In such cases, please put it in the trusted list, exclusion list, etc.

Tutorials on how to use this software is included with it with images.
I did my best to write them, so please read it.

Perhaps it is because I developed this in C#, this software often malfunctions if the Windows system files are damaged.
Before using this software, I recommend that you reboot your PC and apply a repair to the OS system files.
Especially if you have not run any repairs since you bought it, there is a high possibility that it is damaged somewhere.

Start a command prompt with administrator privileges,
DISM.exe /Online /Cleanup-image /Restorehealth
sfc /scannow
Entering the two commands above will repair the problem.
In particular the first command may take some time.

If you want to know more information about DISM.exe and sfc, google these with the keywords.
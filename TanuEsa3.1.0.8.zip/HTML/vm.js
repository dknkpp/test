"use strict";

var voicemod = new VoicemodWebSocket();
voicemod.connect("localhost", "aaaaaa-123456");
// Your logic and listeners go here
voicemod.disconnect();

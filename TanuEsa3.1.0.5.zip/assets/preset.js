﻿presetCount = 50;
presetSize = 30;